var creeps_class = require("./creep.js");
var style = require("../style/creep_style.json");
require("./game_board.js");

// So it can be used in other files
module.exports = {
	Base: Base,
}

//Base object
function Base (x, y, name){
	// Basic constructor
	this.x 		= x;
	this.y 		= y;
	this.name 	= name;
	this.creeps = {};
	this.radar	= 100;

	// Create a new miner
	this.spawn_miner = function(name){
		this.creeps[name] = new creeps_class.Miner(name, this.x, this.y);
	}

	// Run the script of all creeps this base spawned
	this.run_creeps = function(){
		for (var creep in this.creeps) {
			this.creeps[creep].execute();
		}
	}

	// Draw all creeps
	this.draw_creeps = function(){
		// Draw self
		this.draw();

		// Draw all the little creepys
		for (var creep in this.creeps) {
			this.creeps[creep].draw();
		}
	}

	this.draw = function(){
		rect(30, 30, this.x, this.y, style.base.outline, style.base.fill);
	}

	// Find all objects close to us
	// Functionally programmed Version
	// TODO: Actually have a "world" array
	this.radar = function(){
		//Not going to go into the math, but checks if an abject is within the radius of "this"
		var in_radius = function(obj) {
			return (pow((this.x - obj.x), 2) + pow((this.y - obj.y), 2) < pow(this.radar, 2));
		};

		var detected = world.filter(in_radius);

		// Return our detected objects
		return detected;
	}

	// Non-functionally programmed way
	// this.radar = function(){
	// 	//Nothing found
	// 	var detected = [];

	// 	// For every item in this world
	// 	for (var i = world.length - 1; i >= 0; i--) {

	// 		// If it's within the radius of the radar, add it
	// 		if (
	// 			pow((this.x - world[i].x), 2) + pow((this.y - world[i].y), 2)
	// 			< pow(this.radar, 2)
	// 		){
	// 			detected.push(world[i]);
	// 		}
			
	// 	}

	// 	// Return our detected objects
	// 	return detected;
	// }
}