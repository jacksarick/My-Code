var base_class = require("./base.js");

// So it can be used in other files
module.exports = {
	World: World
}

//World object
function World (name){
	// Basic constructor
	this.name 	= name;
	this.base = {};

	// Create a new miner
	this.new_base = function(x, y, name){
		this.base[name] = new base_class.Base(x, y, name);
	}
}
