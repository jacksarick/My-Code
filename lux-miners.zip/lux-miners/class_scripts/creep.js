class Creep {
	// Main constructor
	constructor(x, y, name, base){
		this.x 		= x;
		this.y 		= y;
		this.name 	= name;
		this.base	= base;
		this.health = 100;
		this.level 	= 1;
		this.load 	= {};
		this.script = "//Script goes here";
	}

	// Move the creep
	move(x_inc, y_inc) {
		this.x += x_inc;
		this.y += y_inc;
	}

	// Execute the creep's internal script
	execute(){
		eval(this.script);
	}
}