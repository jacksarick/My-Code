class World {
	constructor(name){
		this.name = name;
		this.objects = [];
	}
}