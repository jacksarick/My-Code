require("./creep.js");

class Miner extends Creep {
	constructor(){
		super();
		this.class = "miner";
	}

	latch_on(source){
		// (x - center_x)^2 + (y - center_y)^2 < radius^2
		return "Failed!";
	}

	// Draw the Miner
	draw(){
		ctx.strokeStyle = "red";
		ctx.fillStyle = "blue";
		ctx.beginPath();
		ctx.rect(this.x, this.y, 20, 20);
		ctx.closePath();
		ctx.fill();
		ctx.stroke();
	}
}