require("./creep.js");

class Base {
	// Basic constructor
	constructor(x, y, name){
		this.x 		= x;
		this.y 		= y;
		this.name 	= name;
		this.creeps = {};
		this.radar	= 100;
	}

	// Create a new miner
	spawn_miner(name){
		this.creeps[name] = new Miner(name);
	}

	// Run the script of all creeps this base spawned
	run_creeps(){
		for (var i = creeps.length - 1; i >= 0; i--) {
			creeps[i].execute();
		}
	}

	draw_creeps(){
		for (var i = creeps.length - 1; i >= 0; i--) {
			creeps[i].draw();
		}
	}

	// Find all objects close to us
	// TODO: Actually have a "world" array
	radar(){
		//Nothing found
		var detected = [];

		// For every item in this world
		for (var i = world.length - 1; i >= 0; i--) {

			// If it's within the radius of the radar, add it
			if (
				pow((this.x - world[i].x), 2) + pow((this.y - world[i].y), 2)
				< pow(this.radar, 2)
			){
				detected.push(world[i]);
			}
			
		}

		// Return our detected objects
		return detected;
	}
}