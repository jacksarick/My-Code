Webcam-Face-Detect
==================

Run the program like this:

python webcam.py haarcascade_frontalface_default.xml

If you want to understand how the code works,  see here: https://realpython.com/blog/python/face-detection-in-python-using-a-webcam/
